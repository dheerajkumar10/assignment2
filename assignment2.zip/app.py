from decimal import Decimal
from math import degrees
from turtle import distance
import pyodbc
from pytz import timezone
import pytz
from flask import Flask, render_template, request
import pandas as pd
import math

app = Flask(__name__)

server = 'dheeraj1045.database.windows.net'
database = 'dheerajdb'
username = 'dheeraj'
password = 'Dheer@jkumar1045'
driver = '{ODBC Driver 17 for SQL Server}'

cnxn = pyodbc.connect('DRIVER='+driver+';PORT=1433;SERVER='+server +
                      ';PORT=1443;DATABASE='+database+';UID='+username+';PWD=' + password)
cursor = cnxn.cursor()


@app.route("/")
def fetchall():
    cursor.execute("SELECT * FROM [dbo].[earthquake]")
    res = cursor.fetchall()
    return render_template('index.html', num=res)


@app.route('/Filter', methods=['GET'])
def filter():
    query = "SELECT * FROM [dbo].[earthquake]"
    if request.args.get('mag'):
        query += " and mag > "+request.args.get('mag')

    if request.args.get('distance'):
        clongitude = request.args.get('long')
        clatitude = request.args.get('lat')
        degrees = 0.009 * float(request.args.get('distance'))
        query += " and Longitude >=" + clatitude + '-' + str(degrees) + " and Longitude <=" + clatitude + '+' + str(
            degrees) + 'and Latitude >=' + clongitude + '-' + str(degrees) + 'and Latitude <=' + clongitude + '+' + str(degrees)

    if request.args.get('lmag'):
        llimit = request.args.get('lmag')

        query += "and mag >= " + llimit

    if request.args.get('hmag'):
        hlimit = request.args.get('hmag')
        query += "and mag  <=" + hlimit

    if request.args.get('fdate'):
        idate = request.args.get('fdate')
        query += "and time >= " + "'" + idate + "'"

    if request.args.get('tdate'):
        fdate = request.args.get('tdate')
        query += "and time <= " + "'" + fdate + "'"

    if request.args.get('ftime'):
        stime = request.args.get('ftime')
        query += "and CAST (time as time) >= " + "'" + stime + "'"

    if request.args.get('ttime'):
        etime = request.args.get('ttime')
        query += "or CAST (time as time) <= " + "'" + etime + "'"

    result = cursor.execute(query)
    return render_template('index.html', num=result)


def euclidean_distance(row1, row2):
    distance = 0.0
    for i in range(len(row1)-1):
        distance = distance + (row1[i] - row2[i])**2
        sqrtdistance = math.sqrt(distance)
    return sqrtdistance


@app.route("/Gclusters", methods=['POST', 'GET'])
def Clusters():
    query = "SELECT latitude, longitude FROM [dbo].[earthquake] "
    df = pd.read_sql(query, cnxn)
    print(df.head(5))
    c1 = (33.288667, -115.991000)
    c2 = (62.056200, -150.887100)
    c3 = (19.698166, -155.176163)
    cluster1 = list()
    cluster2 = list()
    cluster3 = list()
    for index, row in df.iterrows():
        d = euclidean_distance((row['latitude'], row['longitude']), c1)
        e = euclidean_distance((row['latitude'], row['longitude']), c2)
        f = euclidean_distance((row['latitude'], row['longitude']), c3)
        if((d < e) and (d < f)):
            cluster1.append(row)
        elif((e < f) and (e < d)):
            cluster2.append(row)
        elif((f < d) and (f < e)):
            cluster3.append(row)
        else:
            print("")

    print(len(cluster1))
    return render_template('index.html', cluster=cluster1, cluster2=cluster2, cluster3=cluster3)


if __name__ == "__main__":
    app.run(debug=True)
